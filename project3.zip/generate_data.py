"""
generate_data.py  -  builds the SIMULATED demo dataset for Project 3.

Outputs (in ./data):
  posts.csv                 Table A  (social media posts)
  comments.csv              Table B  (comments, with topic / sentiment / purchase_intent labels)
  simulation_ground_truth.csv  which posts were deliberately made unusual (only for testing the engine)

Everything here is SIMULATED. Brands are placeholders (Brand A/B/C), not real companies.
Run:  python generate_data.py
"""
import re
import numpy as np
import pandas as pd
from pathlib import Path

SEED = 42
N_POSTS = 3000
COLLECTION_DATE = "2026-11-13"
rng = np.random.default_rng(SEED)

CITIES = {"Lahore": "لاہور", "Karachi": "کراچی", "Islamabad": "اسلام آباد", "Rawalpindi": "راولپنڈی",
          "Faisalabad": "فیصل آباد", "Multan": "ملتان", "Peshawar": "پشاور", "Sialkot": "سیالکوٹ"}
CITY_W = [0.22, 0.26, 0.14, 0.08, 0.09, 0.08, 0.07, 0.06]

# ---------------------------------------------------------------- comment templates
# topic: (sentiment, purchase_intent, English, Roman Urdu, Urdu)
T = {
 "Price inquiry": ("Neutral", "Possible inquiry",
   ["Price please?", "What is the price of this suit?", "How much is this lawn suit?", "Price?", "Can you tell the price of the 3 piece?"],
   ["Price kya hai?", "Price bata dein plz", "Rate kitna hai iska?", "Kitne ka hai ye suit?", "Price pls dm kar dein", "Iski price kia hai"],
   ["قیمت کیا ہے؟", "پرائس بتائیں", "اس کا ریٹ کیا ہے؟", "یہ سوٹ کتنے کا ہے؟"]),
 "Price complaint": ("Negative", "No intent",
   ["Too expensive for lawn.", "Price is way too high.", "So overpriced these days.", "Not worth this price honestly."],
   ["Price bohat zyada hai.", "Bohat mehnga hai ye to", "Itna mehnga lawn kon kharide ga", "Price bht zyada hai sis", "Rate to aasman pe hain"],
   ["قیمت بہت زیادہ ہے", "بہت مہنگا ہے", "اتنی مہنگی لان کون خریدے گا"]),
 "Discount request": ("Neutral", "Possible inquiry",
   ["Any discount on this suit?", "When is the sale?", "Is there any promo code?", "Will this go on sale for 11.11?", "Any offer on bulk order?"],
   ["Discount milega is pe?", "Sale kab lag rahi hai?", "Koi discount code hai?", "Price kam karo plz", "11.11 sale mein lag jayega?"],
   ["کوئی ڈسکاؤنٹ ہے؟", "سیل کب لگے گی؟", "کچھ کم ہو سکتا ہے؟"]),
 "Delivery inquiry": ("Neutral", "Possible inquiry",
   ["How many days for delivery to {city}?", "Do you deliver to {city}?", "Is there cash on delivery?", "What is the delivery charge?"],
   ["Delivery kitne din mein hogi?", "{city} tak delivery kitne din mein aati hai?", "COD available hai?", "Delivery charges kitne hain?"],
   ["ڈیلیوری کتنے دن میں ہوگی؟", "کیا کیش آن ڈیلیوری ہے؟"]),
 "Order delay complaint": ("Negative", "Existing customer",
   ["Ordered last week, still waiting.", "Still no parcel after 12 days, worst service.", "Order not received yet, no tracking updates.", "Nobody replies to my order complaint."],
   ["Order kiya tha 10 din pehle, abhi tak nahi aaya.", "Parcel abhi tak nahi mila, tracking bhi update nahi", "Worst service, order late ho gaya", "Complaint ki thi koi reply nahi aaya"],
   ["آرڈر کیے ہوئے دس دن ہو گئے ہیں ابھی تک نہیں آیا", "پارسل ابھی تک نہیں ملا", "کوئی جواب نہیں دیتا آرڈر لیٹ ہو گیا"]),
 "Availability inquiry": ("Neutral", "High intent",
   ["Is this available in {city}?", "Is it in stock?", "Do you have this in other colours?", "Is this available in your {city} store?"],
   ["{city} mein available hai?", "Stock mein hai ye?", "Ye suit mil jayega kya?", "Aur colour available hain?", "{city} wali branch mein mil jaye ga?"],
   ["کیا یہ {city_ur} میں دستیاب ہے؟", "اسٹاک میں ہے؟"]),
 "Size inquiry": ("Neutral", "Possible inquiry",
   ["Is size medium available?", "Can you share the size chart?", "What is the shirt length?", "Is this stitched or unstitched?"],
   ["Size chart bhej dein", "Medium size available hai?", "Ye stitched hai ya unstitched?", "Shirt ki length kitni hai?"],
   ["سائز چارٹ بتائیں", "میڈیم سائز دستیاب ہے؟", "یہ سلا ہوا ہے یا ان سلا؟"]),
 "Fabric quality": ("Neutral", "Possible inquiry",
   ["Is it pure lawn or cotton blend?", "Fabric quality is not like the picture.", "The fabric was very thin last time.", "How is the fabric after wash?"],
   ["Kapra kaisa hai, pure lawn hai?", "Fabric quality pehle jaisi nahi rahi", "Kapra bohat patla hai", "Wash ke baad rang jata hai?"],
   ["کپڑا کیسا ہے؟", "فیبرک بہت پتلا ہے", "دھونے کے بعد رنگ نکلتا ہے؟"]),
 "Purchase intent": ("Positive", "High intent",
   ["I want to order 2 suits, how?", "Please inbox me the details.", "Sending DM, I want to buy this.", "Can I order on WhatsApp?"],
   ["Inbox me details send kar dein", "Mujhe ye suit chahiye, order kaise karun?", "Order karna hai, link bhejein", "Dm kiya hai please check kar lein", "WhatsApp number dein order ke liye"],
   ["مجھے آرڈر کرنا ہے", "ان باکس میں تفصیل بھیجیں", "واٹس ایپ نمبر دیں"]),
 "Praise": ("Positive", "No intent",
   ["Very beautiful dress!", "Love this colour", "Gorgeous, the print is so pretty", "Obsessed with this collection"],
   ["Mashallah bohat khoobsurat", "Colour bohat piyara hai", "Kya baat hai, love it", "Sab se best collection"],
   ["ماشاءاللہ بہت خوبصورت", "رنگ بہت پیارا ہے", "بہت زبردست کلیکشن"]),
 "Spam / other": ("Neutral", "No intent",
   ["Follow back please", "Giveaway when?", "Check my page", "nice", "Wow"],
   ["Follow back kar dein", "Giveaway kab hai?", "Meri page check karo", "nice one"],
   ["فالو بیک کریں", "گیو اوے کب ہے؟"]),
}
TOPICS = list(T)
BASE_W = dict(zip(TOPICS, [12, 6, 9, 8, 5, 9, 8, 6, 10, 22, 5]))
CTYPE_TILT = {
 "Reel": {"Praise": 1.5, "Spam / other": 1.3},
 "Product Photo": {"Size inquiry": 1.8, "Fabric quality": 1.6, "Price inquiry": 1.4, "Praise": 0.7},
 "Influencer Post": {"Praise": 1.4, "Price inquiry": 1.5, "Purchase intent": 1.3, "Spam / other": 1.2},
 "Styling Video": {"Fabric quality": 1.3, "Size inquiry": 1.3, "Praise": 1.2, "Purchase intent": 1.2},
 "Sale Announcement": {"Discount request": 2.5, "Price complaint": 1.8, "Availability inquiry": 1.5, "Purchase intent": 1.4, "Praise": 0.5},
 "Eid Campaign": {"Delivery inquiry": 1.8, "Order delay complaint": 1.6, "Purchase intent": 1.5, "Availability inquiry": 1.4},
}
CAMP_TILT = {
 "11.11 Collection": {"Discount request": 1.8, "Order delay complaint": 1.3},
 "12.12 Collection": {"Discount request": 1.7, "Availability inquiry": 1.3, "Price complaint": 1.2},
 "Eid Collection": {"Delivery inquiry": 1.5, "Availability inquiry": 1.3, "Order delay complaint": 1.4},
 "Summer Lawn": {"Fabric quality": 1.5, "Size inquiry": 1.2},
 "New Arrivals": {"Price inquiry": 1.3, "Praise": 1.2},
}
PLAT_TILT = {
 "TikTok": {"Spam / other": 2.0, "Praise": 1.2},
 "Facebook": {"Order delay complaint": 1.4, "Delivery inquiry": 1.3, "Purchase intent": 1.3},
 "Instagram": {"Price inquiry": 1.2},
}

def make_comment(topic, rng):
    _, _, en, ru, ur = T[topic]
    lang = rng.choice(["English", "Roman Urdu", "Urdu"], p=[0.35, 0.50, 0.15])
    tpl = rng.choice({"English": en, "Roman Urdu": ru, "Urdu": ur}[lang])
    city = rng.choice(list(CITIES), p=CITY_W)
    txt = tpl.replace("{city_ur}", CITIES[city]).replace("{city}", city)
    if lang != "Urdu":                                   # messy social-media writing
        if rng.random() < 0.25:
            for a, b in [("bohat", "bht"), ("please", "plz"), ("kya", "kia"), ("mein", "mai"), ("Price", "price")]:
                txt = txt.replace(a, b)
        if rng.random() < 0.20: txt = txt.lower()
        if rng.random() < 0.05: txt = re.sub(r"(e|a|o)\b", r"\1\1\1", txt, count=1)
    if rng.random() < 0.15: txt += " " + rng.choice(["😍", "🔥", "❤️", "🙏", "😭"])
    return txt, lang

# ---------------------------------------------------------------- posts (Table A)
PLATFORMS = ["Instagram", "TikTok", "Facebook"]
CTYPES = list(CTYPE_TILT)
CAMPS = list(CAMP_TILT)
VIEW_BASE = {"Instagram": 18000, "TikTok": 45000, "Facebook": 9000}
VIEW_CT = {"Reel": 1.8, "Product Photo": 0.6, "Influencer Post": 1.3, "Styling Video": 1.4, "Sale Announcement": 1.0, "Eid Campaign": 1.5}
VIEW_CAMP = {"Eid Collection": 1.3, "11.11 Collection": 1.2, "12.12 Collection": 1.15, "Summer Lawn": 1.0, "New Arrivals": 0.9}
LIKE_PLAT = {"Instagram": 0.060, "TikTok": 0.075, "Facebook": 0.030}
LIKE_CT = {"Reel": 1.1, "Product Photo": 1.0, "Influencer Post": 1.2, "Styling Video": 1.15, "Sale Announcement": 0.8, "Eid Campaign": 1.1}
CMT_CT = {"Reel": 0.8, "Product Photo": 1.2, "Influencer Post": 1.4, "Styling Video": 1.0, "Sale Announcement": 2.2, "Eid Campaign": 1.5}
SHR_CT = {"Reel": 0.25, "Product Photo": 0.06, "Influencer Post": 0.12, "Styling Video": 0.22, "Sale Announcement": 0.10, "Eid Campaign": 0.20}

n = N_POSTS
posts = pd.DataFrame({
    "post_id": [f"P{i:04d}" for i in range(1, n + 1)],
    "brand": rng.choice(["Brand A", "Brand B", "Brand C"], n, p=[0.4, 0.35, 0.25]),
    "platform": rng.choice(PLATFORMS, n, p=[0.45, 0.30, 0.25]),
    "campaign": rng.choice(CAMPS, n),
    "content_type": rng.choice(CTYPES, n, p=[0.22, 0.20, 0.14, 0.14, 0.16, 0.14]),
    "product_category": "Lawn suit",
    "days_since_post": rng.integers(1, 46, n),
})
mat = 1 - np.exp(-posts.days_since_post / 4)
views = (posts.platform.map(VIEW_BASE) * posts.content_type.map(VIEW_CT) * posts.campaign.map(VIEW_CAMP)
         * rng.lognormal(0, 0.7, n) * mat)
likes = views * posts.platform.map(LIKE_PLAT) * posts.content_type.map(LIKE_CT) * rng.lognormal(0, 0.2, n)
cmts = likes * 0.06 * posts.content_type.map(CMT_CT) * rng.lognormal(0, 0.3, n)
shares = likes * posts.content_type.map(SHR_CT) * np.where(posts.platform == "TikTok", 1.5, 1) * rng.lognormal(0, 0.3, n)

# deliberately unusual posts (kept in a separate file so the engine can be tested honestly)
atype = np.array([""] * n, dtype=object)
idx = rng.choice(n, int(n * 0.05), replace=False)
kinds = rng.choice(["viral", "flop", "delivery_spike", "price_backlash", "spam_giveaway"], len(idx), p=[.25, .25, .20, .15, .15])
atype[idx] = kinds
spec = {k: {} for k in ["viral", "flop", "delivery_spike", "price_backlash", "spam_giveaway"]}
for i, k in zip(idx, kinds):
    if k == "viral":   f = rng.uniform(15, 40); views[i] *= f; likes[i] *= f; cmts[i] *= f; shares[i] *= f
    if k == "flop":    f = rng.uniform(0.03, 0.08); views[i] *= f; likes[i] *= f; cmts[i] *= f; shares[i] *= f
    if k == "delivery_spike": cmts[i] *= 3
    if k == "spam_giveaway":  cmts[i] *= 5; likes[i] *= 0.5

posts["likes"] = np.maximum(likes.round(), 3).astype(int)
posts["comments_count"] = np.maximum(cmts.round(), 3).astype(int)
posts["shares"] = shares.round().clip(lower=0)
posts["views"] = views.round().clip(lower=1)
# "where publicly available": some platforms hide views or shares
miss_v = ((posts.platform == "Facebook") & (rng.random(n) < 0.35)) | \
         ((posts.platform == "Instagram") & posts.content_type.isin(["Product Photo", "Influencer Post"]) & (rng.random(n) < 0.60)) | \
         ((posts.platform == "Instagram") & (rng.random(n) < 0.05))
miss_s = ((posts.platform == "Instagram") & (rng.random(n) < 0.45)) | ((posts.platform == "Facebook") & (rng.random(n) < 0.15))
posts.loc[miss_v, "views"] = np.nan
posts.loc[miss_s, "shares"] = np.nan

# ---------------------------------------------------------------- comments (Table B)
rows = []
for r, a in zip(posts.itertuples(), atype):
    w = np.array([BASE_W[t] * CTYPE_TILT[r.content_type].get(t, 1) * CAMP_TILT[r.campaign].get(t, 1)
                  * PLAT_TILT[r.platform].get(t, 1) for t in TOPICS], dtype=float)
    if a == "delivery_spike":   w[TOPICS.index("Order delay complaint")] *= 25; w[TOPICS.index("Delivery inquiry")] *= 5
    if a == "price_backlash":   w[TOPICS.index("Price complaint")] *= 28
    if a == "spam_giveaway":    w[TOPICS.index("Spam / other")] *= 40
    w /= w.sum()
    for t in rng.choice(TOPICS, min(r.comments_count, int(rng.integers(5, 13))), p=w):
        txt, lang = make_comment(t, rng)
        rows.append((r.post_id, txt, lang, t, T[t][0], T[t][1]))
comments = pd.DataFrame(rows, columns=["post_id", "comment_text", "language_type", "topic", "sentiment", "purchase_intent"])
comments.insert(0, "comment_id", [f"C{i:05d}" for i in range(1, len(comments) + 1)])

# ---------------------------------------------------------------- provenance columns + save
for df in (posts, comments):
    df["data_provenance"] = "simulated"
posts["source_url"] = "N/A (simulated)"
posts["collection_date"] = COLLECTION_DATE
posts["reuse_permission"] = "Free to reuse: generated by generate_data.py (seed 42), no real accounts or people"
out = Path(__file__).parent / "data"; out.mkdir(exist_ok=True)
posts.to_csv(out / "posts.csv", index=False)
comments.to_csv(out / "comments.csv", index=False, encoding="utf-8")
pd.DataFrame({"post_id": posts.post_id[atype != ""], "anomaly_type": atype[atype != ""]}).to_csv(out / "simulation_ground_truth.csv", index=False)
print(posts.shape, comments.shape, "unusual posts:", int((atype != "").sum()))
