"""
engine.py  -  Pakistan Social Audience & Campaign Intelligence Engine

Pipeline
  1. clean + normalise comments (English / Roman Urdu / Urdu script -> one shared vocabulary)
  2. cluster comments (TF-IDF -> SVD -> KMeans)  -> audience needs / segments
  3. content performance (age-adjusted attention index per platform)
  4. unusual posts (Isolation Forest on peer-normalised metrics + comment mix)
  5. evidence-based recommendations
The topic / sentiment labels in Table B are NOT used for clustering, only to check the result.
"""
import re
import numpy as np
import pandas as pd
from scipy.sparse import hstack
from scipy.stats import mannwhitneyu
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.cluster import KMeans
from sklearn.ensemble import IsolationForest
from sklearn.metrics import silhouette_score, adjusted_rand_score
from sklearn.preprocessing import normalize

SEED = 42
CITIES = ["lahore", "karachi", "islamabad", "rawalpindi", "faisalabad", "multan", "peshawar", "sialkot"]

# ------------------------------------------------------------------ 1. text normalisation
PHRASES = {"ان باکس": "inbox", "کیش آن ڈیلیوری": "cod", "واٹس ایپ": "whatsapp", "فالو بیک": "follow back",
           "گیو اوے": "giveaway", "اسلام آباد": "islamabad", "فیصل آباد": "faisalabad"}
CANON = {  # Urdu script + spelling variants -> one canonical token
    "قیمت": "price", "پرائس": "price", "ریٹ": "price", "rate": "price", "qeemat": "price", "kimat": "price",
    "کتنے": "kitne", "کتنا": "kitna", "kitny": "kitne", "مہنگا": "mehnga", "مہنگی": "mehnga", "mehngi": "mehnga",
    "mahnga": "mehnga", "expensive": "mehnga", "costly": "mehnga", "overpriced": "mehnga", "زیادہ": "zyada", "bht": "bohat",
    "boht": "bohat", "bohot": "bohat", "ڈسکاؤنٹ": "discount", "سیل": "sale", "کم": "kam", "dicount": "discount",
    "ڈیلیوری": "delivery", "deliver": "delivery", "shipping": "delivery", "دن": "din", "آرڈر": "order",
    "نہیں": "nahi", "آیا": "aaya", "ملا": "mila", "پارسل": "parcel", "ابھی": "abhi", "تک": "tak", "لیٹ": "late",
    "جواب": "jawab", "دستیاب": "available", "dastiyab": "available", "avaliable": "available", "اسٹاک": "stock",
    "سائز": "size", "sizes": "size", "چارٹ": "chart", "میڈیم": "medium", "کپڑا": "fabric", "فیبرک": "fabric",
    "kapra": "fabric", "kapda": "fabric", "پتلا": "patla", "خوبصورت": "beautiful", "khoobsurat": "beautiful",
    "khubsurat": "beautiful", "gorgeous": "beautiful", "pretty": "beautiful", "lovely": "beautiful",
    "ماشاءاللہ": "mashallah", "mashaallah": "mashallah", "پیارا": "piyara", "زبردست": "zabardast",
    "نمبر": "number", "dm": "inbox", "kia": "kya", "کیا": "kya", "plz": "pls", "please": "pls", "mai": "mein",
    "me": "mein", "میں": "mein", "ہے": "hai", "کب": "kab", "کوئی": "koi", "کرنا": "karna", "مجھے": "mujhe",
    "چاہیے": "chahiye", "کریں": "karein", "ہوگی": "hogi", "رنگ": "colour", "color": "colour", "کلیکشن": "collection",
    "لاہور": "lahore", "کراچی": "karachi", "راولپنڈی": "rawalpindi", "ملتان": "multan", "پشاور": "peshawar",
    "سیالکوٹ": "sialkot", "سوٹ": "suit", "لان": "lawn", "دھونے": "dhone", "بعد": "baad", "ہو": "ho",
}
STOP = ["is", "the", "this", "a", "an", "of", "to", "in", "for", "it", "on", "hai", "ka", "ki", "ko", "se", "ye",
        "or", "and", "mein", "hain", "ke", "ho", "you", "your", "me", "my", "pls",
        "kya", "koi", "kar", "dein", "karein", "pe", "ya", "aur", "tha", "bhej", "bhejein", "iska", "iski", "sis", "bata", "batain", "batao", "mujhe", "gaya", "rahi", "raha"]
ROMAN_MARKERS = {"hai", "kya", "kitne", "nahi", "bohat", "mein", "karo", "dein", "ka", "ki", "ko", "hain", "aaya",
                 "mila", "chahiye", "mujhe", "kab", "kar", "bhejein", "wali", "jaye", "milega", "sis", "ye", "kaisa",
                 "kaise", "tha", "abhi", "pehle", "mehnga", "kharide", "kapra", "rang", "lag", "tak", "se", "ke"}

def detect_language(text):
    s = str(text)
    if re.search(r"[\u0600-\u06FF]", s): return "Urdu"
    toks = set(re.findall(r"[a-z]+", s.lower()))
    return "Roman Urdu" if len(toks & ROMAN_MARKERS) >= 1 else "English"

def clean_text(s):
    s = str(s).lower()
    s = re.sub(r"https?://\S+", " ", s)
    for k, v in PHRASES.items(): s = s.replace(k, v)
    s = re.sub(r"[^\w\s\u0600-\u06FF]", " ", s)
    s = re.sub(r"(.)\1{2,}", r"\1", s)
    return " ".join(CANON.get(t, t) for t in s.split())

# ------------------------------------------------------------------ 2. audience segments
# Lexicon is used ONLY to give each discovered cluster a readable name (clusters themselves are unsupervised).
NEEDS = {
 "Price questions": r"price|kitne|kitna|how much",
 "Price complaints (too expensive)": r"mehnga|zyada|not worth|too high",
 "Discount seekers": r"discount|sale|promo|kam|code|bulk|offer",
 "Delivery questions": r"delivery|cod|charges|\bdays\b|\bdin\b",
 "Order delay / service complaints": r"waiting|not received|nahi aaya|nahi mila|\blate\b|tracking|parcel|worst|complaint|jawab|nobody|replies|reply|kiya tha|still",
 "Availability & stock (by city)": r"available|stock|mil jaye|mil jayega|colours|branch|" + "|".join(CITIES),
 "Size questions": r"\bsize\b|chart|medium|stitched|length",
 "Fabric & quality": r"fabric|lawn|cotton|wash|patla|thin|quality",
 "Purchase intent (ready to buy)": r"inbox|order karna|want to order|\bbuy\b|whatsapp|chahiye|order kaise|\blink\b|number",
 "Praise & appreciation": r"beautiful|mashallah|love|piyara|zabardast|best collection|obsessed|colour bohat|kya baat",
 "Spam / giveaway / low value": r"follow|giveaway|check my|meri page|\bnice\b|\bwow\b",
}
NEED_KEY = {"Price questions": "price_q", "Price complaints (too expensive)": "price_complaint",
            "Discount seekers": "discount", "Delivery questions": "delivery_q",
            "Order delay / service complaints": "delay", "Availability & stock (by city)": "avail",
            "Size questions": "size", "Fabric & quality": "fabric", "Purchase intent (ready to buy)": "intent",
            "Praise & appreciation": "praise", "Spam / giveaway / low value": "spam"}
TOPIC_TO_NEED = {"Price inquiry": "Price questions", "Price complaint": "Price complaints (too expensive)",
                 "Discount request": "Discount seekers", "Delivery inquiry": "Delivery questions",
                 "Order delay complaint": "Order delay / service complaints", "Availability inquiry": "Availability & stock (by city)",
                 "Size inquiry": "Size questions", "Fabric quality": "Fabric & quality", "Purchase intent": "Purchase intent (ready to buy)",
                 "Praise": "Praise & appreciation", "Spam / other": "Spam / giveaway / low value"}

def _name_clusters(clean, labels, k):
    """name each cluster by the lexicon need that is most specific to it"""
    hit = pd.DataFrame({n: clean.str.contains(p, regex=True) for n, p in NEEDS.items()})
    overall = hit.mean().clip(lower=0.01)
    names = {}
    for c in range(k):
        frac = hit[labels == c].mean()
        names[c] = (frac / np.sqrt(overall)).idxmax()
    return names

def fit_segments(comments, k=40, k_check=(30, 40, 50)):
    """Two-stage clustering of comments.
    Stage 1: KMeans finds k small 'micro-clusters' of similar comments (unsupervised, text only).
    Stage 2: each micro-cluster is named by the need its words match best; clusters with the same need are merged
             into one audience segment.  Returns the labelled comments, segment table and fitted objects."""
    cm = comments.copy().reset_index(drop=True)
    cm["comment_text"] = cm["comment_text"].fillna("").astype(str)
    cm = cm[cm.comment_text.str.strip() != ""].reset_index(drop=True)
    cm["clean"] = cm.comment_text.map(clean_text)
    cm = cm[cm.clean != ""].reset_index(drop=True)
    if "language_type" not in cm.columns: cm["language_type"] = cm.comment_text.map(detect_language)
    k = int(min(k, max(2, len(cm) // 20)))
    vw = TfidfVectorizer(ngram_range=(1, 2), min_df=3, sublinear_tf=True, stop_words=STOP)
    vc = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=5, sublinear_tf=True)
    Xw, Xc = vw.fit_transform(cm.clean), vc.fit_transform(cm.clean)
    X = hstack([Xw, 0.3 * Xc]).tocsr()
    svd = TruncatedSVD(n_components=min(60, X.shape[1] - 1), random_state=SEED)
    Z = normalize(svd.fit_transform(X))
    scores = {}
    for kk in k_check:
        if kk < len(cm) // 20:
            lab = KMeans(kk, n_init=3, random_state=SEED).fit_predict(Z)
            scores[kk] = silhouette_score(Z, lab, sample_size=min(3000, len(Z)), random_state=SEED)
    km = KMeans(k, n_init=10, random_state=SEED).fit(Z)
    micro = pd.Series(km.labels_)
    names = _name_clusters(cm.clean, micro, k)
    cm["micro_cluster"] = micro.values
    cm["need"] = cm.micro_cluster.map(names)
    cm["segment"] = cm["need"]
    terms = np.array(vw.get_feature_names_out())
    rows = []
    for need, grp in cm.groupby("need"):
        idx = grp.index.values
        cent = np.asarray(Xw[idx].mean(axis=0)).ravel()
        d = ((Z[idx] - Z[idx].mean(0)) ** 2).sum(1)
        ex = cm.comment_text.iloc[idx[np.argsort(d)]].drop_duplicates().head(3).tolist()
        rows.append(dict(segment=need, comments=len(idx), share=len(idx) / len(cm),
                         micro_clusters=int(grp.micro_cluster.nunique()),
                         top_terms=", ".join(terms[np.argsort(-cent)[:6]]),
                         **{'english_%': round((grp.language_type == "English").mean() * 100),
                         'roman_urdu_%': round((grp.language_type == "Roman Urdu").mean() * 100),
                         'urdu_script_%': round((grp.language_type == "Urdu").mean() * 100)},
                         examples=" | ".join(ex)))
    seg = pd.DataFrame(rows).sort_values("comments", ascending=False).reset_index(drop=True)
    check = {}
    if "topic" in cm.columns:
        t = cm.topic.astype(str)
        tn = t.map(TOPIC_TO_NEED)
        check["micro_cluster_ARI_vs_topic"] = adjusted_rand_score(t, cm.micro_cluster)
        if tn.notna().all():
            check["segment_ARI_vs_topic"] = adjusted_rand_score(tn, cm.need)
            check["segment_matches_topic"] = float((tn == cm.need).mean())
    return dict(comments=cm, segments=seg, k=k, silhouette=scores, check=check,
                vw=vw, vc=vc, svd=svd, km=km, names=names)

def predict_need(model, text):
    c = clean_text(text)
    X = hstack([model["vw"].transform([c]), 0.3 * model["vc"].transform([c])]).tocsr()
    z = normalize(model["svd"].transform(X))
    return model["names"][int(model["km"].predict(z)[0])]

# ------------------------------------------------------------------ 3. content performance
def prepare_posts(posts):
    p = posts.copy()
    for col in ["likes", "comments_count", "shares", "views", "days_since_post"]:
        p[col] = pd.to_numeric(p[col], errors="coerce") if col in p.columns else np.nan
    p["engagement_rate"] = np.where(p.views > 0, (p.likes + p.comments_count + p.shares.fillna(0)) / p.views, np.nan)
    p["age_bucket"] = pd.cut(p.days_since_post.fillna(15), [-1, 3, 7, 14, 10**6], labels=["0-3d", "4-7d", "8-14d", "15d+"]).astype(str)
    score = p.likes + 2 * p.comments_count                      # always available, so used for ranking
    p["attention_index"] = score.groupby([p.platform, p.age_bucket]).rank(pct=True) * 100   # fair across platform + post age
    return p

def content_summary(p, by="content_type"):
    g = p.groupby(by)
    out = pd.DataFrame({
        "posts": g.size(), "attention_index": g.attention_index.median(), "median_likes": g.likes.median(),
        "median_comments": g.comments_count.median(), "median_shares": g.shares.median(), "median_views": g.views.median(),
        "engagement_rate_%": g.engagement_rate.median() * 100, "views_available_%": g.views.apply(lambda s: s.notna().mean() * 100)})
    return out.sort_values("attention_index", ascending=False).round(1)

# ------------------------------------------------------------------ 4. unusual posts
def add_comment_mix(p, cm):
    """share of each audience need in the sampled comments of each post"""
    mix = pd.crosstab(cm.post_id, cm.need, normalize="index").rename(columns=NEED_KEY)
    cnt = cm.groupby("post_id").size().rename("sampled_comments")
    p = p.drop(columns=[c for c in list(NEED_KEY.values()) + ["sampled_comments"] if c in p.columns]).merge(mix, left_on="post_id", right_index=True, how="left").merge(cnt, left_on="post_id", right_index=True, how="left")
    for k in NEED_KEY.values():
        if k not in p.columns: p[k] = 0.0
    p[list(NEED_KEY.values())] = p[list(NEED_KEY.values())].fillna(0.0)
    p["sampled_comments"] = p.sampled_comments.fillna(0)
    return p

def _rz(s, grp):
    med = s.groupby(grp).transform("median")
    mad = (s - med).abs().groupby(grp).transform("median") * 1.4826
    return ((s - med) / mad.replace(0, np.nan).fillna(s.std() or 1)).clip(-8, 8), med

def detect_anomalies(p, contamination=0.05):
    p = p.copy()
    grp = [p.platform, p.content_type, p.age_bucket]            # "comparable posts"
    ll, cc = np.log1p(p.likes), np.log1p(p.comments_count)
    ratio = np.log((p.comments_count + 1) / (p.likes + 1))
    F = pd.DataFrame(index=p.index)
    F["z_likes"], med_l = _rz(ll, grp)
    F["z_comments"], med_c = _rz(cc, grp)
    F["z_ratio"], _ = _rz(ratio, grp)
    F["z_eng"], _ = _rz(np.log(p.engagement_rate.replace(0, np.nan)), grp)
    F = F.fillna(0)
    F["delay"], F["price_complaint"], F["spam"] = p.delay, p.price_complaint, p.spam
    iso = IsolationForest(n_estimators=300, contamination=contamination, random_state=SEED).fit(F)
    raw = -iso.score_samples(F)
    p["anomaly_score"] = (100 * (raw - raw.min()) / (raw.max() - raw.min())).round(1)
    p["flagged"] = iso.predict(F) == -1
    p["peer_median_likes"], p["peer_median_comments"] = np.expm1(med_l).round(), np.expm1(med_c).round()
    p = p.join(F[["z_likes", "z_comments", "z_ratio"]])
    def why(r):
        out = []
        if r.z_likes > 3: out.append(f"likes {int(r.likes):,} vs ~{int(r.peer_median_likes):,} for similar posts")
        if r.z_likes < -3: out.append(f"very low likes {int(r.likes):,} vs ~{int(r.peer_median_likes):,} for similar posts")
        if r.z_comments > 3: out.append(f"comments {int(r.comments_count):,} vs ~{int(r.peer_median_comments):,} for similar posts")
        if r.delay >= 0.35: out.append(f"order-delay complaints = {r.delay:.0%} of sampled comments")
        if r.price_complaint >= 0.30: out.append(f"'too expensive' comments = {r.price_complaint:.0%}")
        if r.spam >= 0.40: out.append(f"spam/giveaway comments = {r.spam:.0%}")
        if not out and r.z_ratio > 3: out.append("many more comments per like than similar posts")
        return "; ".join(out) or "unusual mix of metrics"
    p["why_unusual"] = ""
    p.loc[p.flagged, "why_unusual"] = p[p.flagged].apply(why, axis=1)
    return p

def evaluate_anomalies(p, truth):
    t = set(truth.post_id); f = set(p.post_id[p.flagged])
    top = set(p.nlargest(len(t), "anomaly_score").post_id)
    return dict(true_unusual=len(t), flagged=len(f), caught=len(t & f), recall=len(t & f) / len(t),
                precision=len(t & f) / max(len(f), 1), precision_at_n=len(t & top) / len(t))

# ------------------------------------------------------------------ 5. recommendations
def _mw(a, b):
    a, b = a.dropna(), b.dropna()
    return mannwhitneyu(a, b, alternative="two-sided").pvalue if len(a) > 8 and len(b) > 8 else np.nan

def build_recommendations(p, cm):
    recs = []
    def add(area, action, evidence): recs.append(dict(area=area, action=action, evidence=evidence))
    n_cm = max(len(cm), 1)
    sh = lambda need: (cm.need == need).mean()
    # content
    cs = content_summary(p)
    if len(cs) >= 2:
        top, bot = cs.index[0], cs.index[-1]
        pv = _mw(p.attention_index[p.content_type == top], p.attention_index[p.content_type != top])
        add("Content", f"Put more budget into {top} posts and cut back on {bot}.",
            f"{top}: attention index {cs.attention_index.iat[0]:.0f}/100 (n={cs.posts.iat[0]}) vs {bot}: {cs.attention_index.iat[-1]:.0f}/100 (n={cs.posts.iat[-1]}); "
            f"{top} vs all other formats p={pv:.3g}. Index = rank of likes + 2x comments among posts on the same platform and of similar age (50 = typical).")
        best = p.groupby(["campaign", "content_type"]).attention_index.agg(["mean", "size"]).query("size >= 8").reset_index()
        if len(best):
            b = best.loc[best.groupby("campaign")["mean"].idxmax()]
            add("Content", "Pick the format by campaign: " + "; ".join(f"{r.campaign} -> {r.content_type}" for r in b.itertuples()) + ".",
                "Best average attention index per campaign (groups with 8+ posts): " + ", ".join(f"{r.campaign} {r.content_type} {r.mean:.0f}" for r in b.itertuples()))
    # promotions
    pr = p.groupby("campaign")[["discount", "price_complaint", "price_q"]].mean().sum(axis=1)
    if len(pr):
        c = pr.idxmax(); overall = sh("Discount seekers") + sh("Price complaints (too expensive)") + sh("Price questions")
        add("Promotions", f"Use a time-limited offer or bundle in '{c}', and write the price in the caption so people stop asking.",
            f"In '{c}' posts {pr.max():.0%} of comments are about discounts, price questions or 'too expensive' (all campaigns: {overall:.0%}). "
            f"Discount seekers alone are {sh('Discount seekers'):.1%} of all comments.")
    # customer service
    d_all = sh("Order delay / service complaints")
    byp = p.groupby("platform").delay.mean()
    if len(byp):
        add("Customer service", "Pin a delivery-time message, reply to order complaints within 24 hours, and send tracking links.",
            f"Order-delay complaints are {d_all:.1%} of comments and delivery questions {sh('Delivery questions'):.1%}; worst platform: {byp.idxmax()} ({byp.max():.1%} of its sampled comments).")
    # availability by city
    av = cm[cm.need.isin(["Availability & stock (by city)", "Delivery questions"])]
    city_pat = "|".join(CITIES)
    found = av.clean.str.findall(city_pat).explode().dropna().value_counts()
    if len(found):
        top3 = found.head(3)
        add("Product / stock", "Add 'available in ' and delivery time for " + ", ".join(c.title() for c in top3.index) + " to captions.",
            f"{sh('Availability & stock (by city)'):.1%} of comments ask about availability; most-named cities: " + ", ".join(f"{c.title()} ({v})" for c, v in top3.items()) + ".")
    # sales conversion
    it = cm[cm.need == "Purchase intent (ready to buy)"]
    if len(it):
        ru = (it.language_type == "Roman Urdu").mean()
        add("Sales", "Reply to buying-intent comments within 1 hour with a ready DM template" + (" written in Roman Urdu." if ru >= 0.4 else "."),
            f"{len(it):,} comments ({len(it)/n_cm:.1%}) show buying intent ('inbox me details', 'order karna hai'); {ru:.0%} are Roman Urdu, {(it.language_type=='Urdu').mean():.0%} Urdu script.")
    # campaign testing
    if len(cs) >= 3:
        a, b = cs.index[0], cs.index[1]
        pv = _mw(p.attention_index[p.content_type == a], p.attention_index[p.content_type == b])
        plat = p.platform.value_counts().idxmax()
        verdict = "not clearly different yet" if (pv != pv or pv > 0.05) else "clearly different"
        add("Campaign testing", f"Run an A/B test on {plat}: same product and caption as {a} vs {b}, 2 weeks, 10+ posts each. Track engagement rate and DMs.",
            f"The top two formats ({a} {cs.attention_index.iat[0]:.0f}, {b} {cs.attention_index.iat[1]:.0f}) are {verdict} (p={pv:.3g}).")
    # unusual posts
    if "flagged" in p.columns and p.flagged.any():
        f = p[p.flagged].sort_values("anomaly_score", ascending=False)
        add("Investigate", "Review the flagged posts first: copy what worked (viral) and fix what hurt (complaint spikes, spam).",
            f"{len(f)} posts flagged; top 3: " + ", ".join(f"{r.post_id} ({r.why_unusual.split(';')[0]})" for r in f.head(3).itertuples()))
    df = pd.DataFrame(recs); df.insert(0, "priority", range(1, len(df) + 1))
    return df

# ------------------------------------------------------------------ full pipeline
def run_pipeline(posts, comments, k=40):
    seg = fit_segments(comments, k=k)
    p = add_comment_mix(prepare_posts(posts), seg["comments"])
    p = detect_anomalies(p)
    return dict(posts=p, seg=seg)

if __name__ == "__main__":
    from pathlib import Path
    d = Path(__file__).parent / "data"
    posts, comments = pd.read_csv(d / "posts.csv"), pd.read_csv(d / "comments.csv")
    r = run_pipeline(posts, comments)
    s = r["seg"]
    print("k =", s["k"], "| silhouette:", {k: round(v, 3) for k, v in s["silhouette"].items()})
    print("check vs simulated labels:", {k: round(v, 3) for k, v in s["check"].items()})
    print(s["segments"][["segment", "comments", "share", "roman_urdu_%", "top_terms"]].to_string())
    print(content_summary(r["posts"]).to_string())
    truth = pd.read_csv(d / "simulation_ground_truth.csv")
    print("anomaly check:", {k: round(v, 3) for k, v in evaluate_anomalies(r["posts"], truth).items()})
    print(build_recommendations(r["posts"], s["comments"]).to_string())
