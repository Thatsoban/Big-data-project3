"""
app.py  -  Pakistan Social Audience & Campaign Intelligence Engine (Streamlit web app)
Run:  streamlit run app.py
"""
from pathlib import Path
import pandas as pd
import plotly.express as px
import streamlit as st
import engine as E

st.set_page_config(page_title="Audience & Campaign Intelligence Engine", page_icon="📊", layout="wide")
DATA = Path(__file__).parent / "data"
NEED_ORDER = list(E.NEEDS)

@st.cache_data
def load_demo():
    return pd.read_csv(DATA / "posts.csv"), pd.read_csv(DATA / "comments.csv")

@st.cache_resource(show_spinner="Clustering comments and scanning posts (about 20 seconds the first time)...")
def analyse(posts, comments, k):
    return E.run_pipeline(posts, comments, k)

def check_columns(posts, comments):
    need_p = {"post_id", "platform", "content_type", "campaign", "likes", "comments_count"}
    need_c = {"post_id", "comment_text"}
    miss = [f"posts.csv is missing: {sorted(need_p - set(posts.columns))}" if need_p - set(posts.columns) else "",
            f"comments.csv is missing: {sorted(need_c - set(comments.columns))}" if need_c - set(comments.columns) else ""]
    return [m for m in miss if m]

# ---------------------------------------------------------------- sidebar
st.sidebar.title("Data")
src = st.sidebar.radio("Source", ["Demo dataset (simulated)", "Upload my own CSVs"])
if src.startswith("Demo"):
    posts_raw, comments_raw = load_demo()
else:
    up_p = st.sidebar.file_uploader("Table A: posts.csv", type="csv")
    up_c = st.sidebar.file_uploader("Table B: comments.csv", type="csv")
    if not (up_p and up_c):
        st.info("Upload both files. Posts need: post_id, platform, content_type, campaign, likes, comments_count "
                "(optional: brand, shares, views, days_since_post). Comments need: post_id, comment_text.")
        st.stop()
    posts_raw, comments_raw = pd.read_csv(up_p), pd.read_csv(up_c)
    errs = check_columns(posts_raw, comments_raw)
    if errs:
        st.error(" | ".join(errs)); st.stop()
k = st.sidebar.slider("Comment micro-clusters (stage 1)", 20, 60, 40, help="More clusters = finer groups. They are merged into audience needs in stage 2.")
res = analyse(posts_raw, comments_raw, k)
P_all, SEG = res["posts"], res["seg"]
plats = st.sidebar.multiselect("Platform", sorted(P_all.platform.unique()), default=sorted(P_all.platform.unique()))
camps = st.sidebar.multiselect("Campaign", sorted(P_all.campaign.unique()), default=sorted(P_all.campaign.unique()))
P = P_all[P_all.platform.isin(plats) & P_all.campaign.isin(camps)]
CM = SEG["comments"][SEG["comments"].post_id.isin(P.post_id)]
if P.empty or CM.empty:
    st.warning("No data for this filter."); st.stop()

st.title("📊 Pakistan Social Audience & Campaign Intelligence Engine")
simulated = "data_provenance" in P.columns and (P.data_provenance.astype(str).str.lower() == "simulated").all()
if simulated:
    st.warning("**This demo data is SIMULATED** (made by generate_data.py). No real brand, account or person is represented. "
               "Findings show that the method works; they are not facts about any real brand.")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Posts", f"{len(P):,}"); c2.metric("Comments analysed", f"{len(CM):,}")
c3.metric("Audience segments found", CM.need.nunique()); c4.metric("Posts flagged unusual", int(P.flagged.sum()))

tabs = st.tabs(["1 · What gets attention", "2 · What the audience wants", "3 · Unusual posts",
                "4 · Audience segments", "5 · What to do next", "Data & method"])

# ---------------------------------------------------------------- tab 1
with tabs[0]:
    st.subheader("Which content attracts attention?")
    st.caption("Attention index (0-100) = rank of likes + 2 x comments among posts on the same platform and of similar age. 50 = typical post.")
    cs = E.content_summary(P)
    a, b = st.columns(2)
    f = px.bar(cs.reset_index(), x="content_type", y="attention_index", color="attention_index", color_continuous_scale="Blues",
               text="attention_index", title="Attention index by content type")
    f.update_layout(coloraxis_showscale=False, xaxis_title=None); a.plotly_chart(f, width="stretch")
    hm = P.pivot_table(index="content_type", columns="campaign", values="attention_index", aggfunc="mean")
    b.plotly_chart(px.imshow(hm, text_auto=".0f", color_continuous_scale="Blues", aspect="auto", title="Attention index: content type x campaign"), width="stretch")
    st.dataframe(cs, width="stretch")
    pc = E.content_summary(P, "platform")
    st.markdown("**By platform** (likes, comments, shares and views are used only where the platform shows them)")
    st.dataframe(pc, width="stretch")

# ---------------------------------------------------------------- tab 2
with tabs[1]:
    st.subheader("What does the audience want?")
    share = CM.need.value_counts(normalize=True).mul(100).round(1).rename("share_%").reset_index()
    a, b = st.columns([1, 1])
    a.plotly_chart(px.bar(share.sort_values("share_%"), x="share_%", y="need", orientation="h", text="share_%", title="Share of all comments (%)").update_layout(yaxis_title=None), width="stretch")
    lang = pd.crosstab(CM.need, CM.language_type, normalize="index").mul(100).round(0)
    b.plotly_chart(px.imshow(lang, text_auto=".0f", color_continuous_scale="Greens", aspect="auto", title="Language of each need (% of that need's comments)"), width="stretch")
    by = st.radio("Break down by", ["campaign", "platform", "content_type"], horizontal=True)
    mix = CM.merge(P[["post_id", by]], on="post_id").pipe(lambda d: pd.crosstab(d[by], d.need, normalize="index").mul(100).round(1))
    st.plotly_chart(px.imshow(mix, text_auto=".0f", color_continuous_scale="Oranges", aspect="auto", title=f"Comment needs by {by} (% of comments)"), width="stretch")

# ---------------------------------------------------------------- tab 3
with tabs[2]:
    st.subheader("Which marketing patterns are unusual?")
    st.caption("A post is compared with similar posts (same platform, content type and age). An Isolation Forest then flags posts whose likes, comments, "
               "engagement or comment mix (complaints, spam) do not fit. Flagged means 'worth a look', not 'wrong'.")
    P2 = P.assign(status=P.flagged.map({True: "flagged", False: "normal"}))
    st.plotly_chart(px.scatter(P2, x="likes", y="comments_count", color="status", log_x=True, log_y=True,
                               color_discrete_map={"flagged": "#d62728", "normal": "#c7c7c7"},
                               hover_data=["post_id", "platform", "content_type", "campaign", "why_unusual"]), width="stretch")
    fl = P[P.flagged].sort_values("anomaly_score", ascending=False)[["post_id", "brand", "platform", "campaign", "content_type", "likes", "comments_count", "anomaly_score", "why_unusual"]] if "brand" in P.columns else P[P.flagged].sort_values("anomaly_score", ascending=False)[["post_id", "platform", "campaign", "content_type", "likes", "comments_count", "anomaly_score", "why_unusual"]]
    st.dataframe(fl, width="stretch")
    st.download_button("Download flagged posts (CSV)", fl.to_csv(index=False).encode("utf-8"), "flagged_posts.csv", "text/csv")

# ---------------------------------------------------------------- tab 4
with tabs[3]:
    st.subheader("Which audience needs should the brand address?")
    sg = SEG["segments"].copy()
    st.dataframe(sg.assign(share=(sg.share * 100).round(1)).rename(columns={"share": "share_%"}), width="stretch", hide_index=True)
    st.caption(f"Stage 1 found {SEG['k']} micro-clusters of similar comments; stage 2 merged those with the same need into the segments above.")
    st.markdown("**Try it:** paste a new comment and see which segment it falls into.")
    t = st.text_input("Comment", "Delivery Multan tak kitne din mein hogi?")
    if t.strip(): st.success(f"Segment: **{E.predict_need(SEG, t)}**")

# ---------------------------------------------------------------- tab 5
with tabs[4]:
    st.subheader("What should the marketing team do next?")
    R = E.build_recommendations(P, CM)
    for r in R.itertuples():
        with st.container(border=True):
            st.markdown(f"**{r.priority}. {r.area}:** {r.action}")
            st.caption("Evidence: " + r.evidence)
    st.download_button("Download recommendations (CSV)", R.to_csv(index=False).encode("utf-8"), "recommendations.csv", "text/csv")

# ---------------------------------------------------------------- tab 6
with tabs[5]:
    st.subheader("Data provenance")
    prov = {"Source": "Simulated by generate_data.py (seed 42)" if simulated else "User-uploaded files",
            "Collection date": ", ".join(P.collection_date.astype(str).unique()[:3]) if "collection_date" in P.columns else "not given",
            "Source URL": ", ".join(P.source_url.astype(str).unique()[:3]) if "source_url" in P.columns else "not given",
            "Reuse permission": ", ".join(P.reuse_permission.astype(str).unique()[:2]) if "reuse_permission" in P.columns else "not given"}
    st.table(pd.Series(prov, name="value"))
    st.markdown("""
**Table A (posts):** post_id, brand, platform, campaign, content_type, product_category, likes, comments_count, shares and views (blank where the platform hides them), days_since_post.
**Table B (comments):** comment_id, post_id, comment_text, language_type, topic, sentiment, purchase_intent. Topic, sentiment and intent labels are *not* used by the clustering, only to check it.

**Method.** (1) Clean text and map Urdu script and Roman Urdu spelling variants to one vocabulary. (2) TF-IDF (words + character n-grams) -> SVD -> KMeans micro-clusters.
(3) Name each cluster by the need its words match, merge clusters with the same need. (4) Attention index = rank of likes + 2 x comments within platform and post-age group.
(5) Isolation Forest on peer-normalised metrics + comment mix. (6) Rule-based recommendations, each with its numbers.""")
    if SEG["check"]:
        st.markdown("**Check against the simulated labels (src: Table B topic column)**")
        st.json({k_: round(float(v), 3) for k_, v in SEG["check"].items()})
    truth_f = DATA / "simulation_ground_truth.csv"
    if simulated and truth_f.exists():
        ev = E.evaluate_anomalies(P_all, pd.read_csv(truth_f))
        st.markdown("**Unusual-post detection vs the posts made unusual on purpose**")
        st.json({k_: round(float(v), 3) for k_, v in ev.items()})
    st.caption("Limits: simulated data is cleaner than real comments; keyword naming covers 11 needs only; real use needs data collected under each platform's terms.")
