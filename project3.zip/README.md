# Project 3: Pakistan Social Audience & Campaign Intelligence Engine (Clustering Based)

**Student:** Soban Imtiaz | **Roll No:** f2024376178 | **Course:** Big Data, UMT Lahore

A small web app for a Lahore-based online fashion brand (women's lawn suits). It groups what people say in comments,
finds unusual posts, and turns both into marketing actions. It is not a positive/negative classifier (that was Project 1).

## Run it
```
pip install -r requirements.txt
python generate_data.py        # optional: rebuilds data/ (already included)
streamlit run app.py
python engine.py               # optional: prints the results below in the terminal
```

## The five questions -> app tabs
| Question from the brief | Tab | How it is answered |
|---|---|---|
| Which content attracts attention? | 1 | Attention index by content type, platform and campaign (likes, comments, shares, views only where available) |
| What does the audience want? | 2 | Comments grouped into 11 needs (price, fabric, sizing, delivery, discount, availability, purchase interest...), by language, campaign, platform |
| Which marketing patterns are unusual? | 3 | Isolation Forest vs comparable posts, with a plain-English reason per flagged post |
| Which audience needs should the brand address? | 4 | Discovered segments with size, language mix, top words, example comments, plus a "try your own comment" box |
| What should the marketing team do next? | 5 | 8 evidence-based recommendations (content, promotions, customer service, stock, sales, campaign testing, investigation) |

## Data (read this part)
**All demo data is SIMULATED.** It was made by `generate_data.py` (seed 42). Brands are placeholders (Brand A/B/C).
No real account, person or comment is used, so nothing here breaks any platform's terms.
- `data/posts.csv` is **Table A**: 3,000 posts. Fields: post_id, brand, platform (Instagram/TikTok/Facebook), campaign (11.11, 12.12, Eid, Summer Lawn, New Arrivals),
  content_type (Reel, Product Photo, Influencer Post, Styling Video, Sale Announcement, Eid Campaign), product_category (Lawn suit), likes, comments_count,
  shares and views (left blank for about 25% and 20% of posts, like platforms that hide them), days_since_post.
- `data/comments.csv` is **Table B**: 25,203 comments in English (35%), Roman Urdu (50%) and Urdu script (15%), with topic, sentiment, purchase_intent.
- Provenance columns on every row: `data_provenance` = simulated, `source_url`, `collection_date`, `reuse_permission`.
- `data/simulation_ground_truth.csv` lists the 150 posts that were made unusual on purpose. It is used only to test the engine.

The topic/sentiment labels are **never used for clustering**. They are only used afterwards to check the result.
**Real data:** use the sidebar "Upload my own CSVs". Only post_id, platform, content_type, campaign, likes, comments_count (posts) and post_id, comment_text (comments) are required.
Collect real data only through permitted access methods and keep source URL, date and permissions in the provenance columns.
Project 2's CSV (ad spend, no comments) and Project 1's YouTube file (iPhone video, English only) were not used: neither has posts + fashion comments.

## Method
1. **Clean + normalise text:** lower-case, remove links/emoji, shorten stretched letters, map Urdu-script words and Roman Urdu spellings ("bht", "bohat", "قیمت", "price") to one shared vocabulary.
2. **Stage 1, clustering:** TF-IDF on words + character n-grams -> SVD (60 dims) -> KMeans with 40 micro-clusters (slider in the app).
3. **Stage 2, naming:** each micro-cluster gets the need whose keywords fit it best; clusters with the same need merge into one segment. Keywords only name clusters; they do not make them.
4. **Attention index:** rank of likes + 2 x comments among posts on the same platform and of similar age (0-100, 50 = typical).
5. **Unusual posts:** compare each post with posts of the same platform, content type and age (robust z-scores of likes, comments, comment/like ratio, engagement rate), add the share of complaint and spam comments, run Isolation Forest (5% flagged).
6. **Recommendations:** rules that read the results above, each with its numbers and a Mann-Whitney test where two groups are compared.

## Results on the demo data
- **Content:** Reel has the highest attention index (70), then Eid Campaign (64), Influencer Post (61), Styling Video (57), Sale Announcement (35), Product Photo (21). Reel vs other formats p < 0.001. Reel vs Eid Campaign is not clearly different (p = 0.37), so an A/B test is recommended.
- **Audience needs (share of comments):** Praise 19%, Price questions 16%, Discount seekers 10%, Purchase intent 9%, Availability 8%, Delivery questions 8%, Size 7%, Fabric 7%, Order-delay complaints 6%, Spam 6%, "Too expensive" 4%.
- **Customer service:** order-delay complaints are 6% of comments; Facebook is worst (7.7%).
- **Stock:** Karachi, Lahore and Islamabad are the most-named cities in availability/delivery comments.
- **Sales:** 9% of comments show buying intent and most are Roman Urdu, so reply templates should be Roman Urdu.

## How well does it work? (simulated data only)
- Segments vs the simulated topic labels: **87%** of comments land in the matching need; adjusted Rand index **0.78** (1.0 = perfect). Weakest need: price questions that also mention discounts or inbox.
- Silhouette score for 30 / 40 / 50 micro-clusters: 0.47 / 0.59 / 0.70 (short templated comments cluster tightly, so real data will score lower).
- Unusual posts: 109 of the 150 planted posts were caught (**73%** recall and precision, because 150 posts are flagged). Spam posts are caught almost always; planted complaint spikes and "flop" posts are caught less often because only 5-12 comments per post are sampled.

## Limits
- Simulated data is cleaner and more repetitive than real comments, so the scores above are optimistic.
- The segment names come from a keyword list for 11 needs; a new kind of need would be clustered but named by the closest match.
- Attention index ignores paid boosts and post time of day. Flagged means "worth checking", not "wrong".
- Sampled comments (5-12 per post) stand in for all comments of the post.

## Files to upload
`app.py`, `engine.py`, `generate_data.py`, `requirements.txt`, `README.md`, `data/posts.csv`, `data/comments.csv`, `data/simulation_ground_truth.csv`
